# Verity Client 5.1.0 | Unhinged Edition
Fabric 1.21.11, Java 21, private single-player only. Unofficial fan-inspired Minecraft sandbox mod.

## New modules
- Crazy Reach: adds 29 blocks to vanilla entity interaction range (32 blocks in standard survival); creative and other modifiers may affect actual range.
- Aimbot: snaps view toward the nearest visible mob within current reach.
- Trigger Bot: attacks a visible mob under the crosshair when the attack is ready.
- Kill Aura: attacks nearest visible mob within reach when the attack is ready.
- Rapid Hit: adds 36 to attack speed; normal game damage immunity may still limit damage.
- Block Reach: adds 27.5 blocks to normal block interaction distance (32 in standard survival).
- Crazy Speed: Speed XX; Super Jump: Jump Boost XV; God Mode: Resistance V (not immunity to every damage source); Mega Mine: Haste XX (not every block instant).
- Existing 12 modules and 6 world actions retained. Extreme tab and all-on Rage Mode.
- Automated combat targets mobs only, pauses in menus, and never operates in multiplayer or LAN. It may target passive mobs; back up your world before use.
- Temporary range and attack-speed modifiers are removed when disabled or LAN is opened; effect refresh stops and effects expire after about 2 seconds. World actions are not automatically undone.
- Original shaded mascot, expressions, hand poses, cartoon exit, voice/SFX, music loop, HUD and included custom music resource pack retained. Original Verity song not bundled; see REPLACE-THEME.txt to use your own copy.

## Build
Install Java 21 and Gradle 9.2.1. Extract ZIP and run build.bat. First build requires internet. Put build/libs/verity-client-5.1.0.jar into .minecraft/mods alongside Fabric API for Minecraft 1.21.11. Press Right Shift in a private single-player world. No multiplayer or LAN support.

## Verification
Source release, not compiled or tested in-game. Module values are intended settings rather than measured results. Original fan artwork, not exact official assets. No official affiliation.

## 1.21.11 port
Loom 1.14.10, Yarn 1.21.11+build.6, Loader 0.18.1, Fabric API 0.141.1+1.21.11. Updated screen keyboard and mouse events, keybinding category, HUD registration, GUI texture pipeline, permission and command dispatch APIs, and the custom music pack metadata. Source-level port only; dependencies could not be downloaded in this environment and no JAR was built.
