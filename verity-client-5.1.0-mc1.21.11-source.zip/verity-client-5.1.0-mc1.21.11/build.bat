@echo off
setlocal
cd /d "%~dp0"
set "G=%USERPROFILE%\gradle\gradle-9.2.1\bin\gradle.bat"
if exist "%G%" (
  call "%G%" clean build
) else (
  call gradle clean build
)
if errorlevel 1 (
  echo Build failed. Install Java 21 and Gradle 9.2.1 or a compatible newer version, then inspect the error above.
) else (
  echo Build complete. Use build\libs\verity-client-5.1.0.jar ^(not sources^).
  explorer "%~dp0build\libs"
)
pause
