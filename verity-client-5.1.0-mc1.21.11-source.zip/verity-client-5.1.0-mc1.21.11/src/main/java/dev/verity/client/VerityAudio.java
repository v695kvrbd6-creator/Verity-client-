package dev.verity.client;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
final class VerityAudio {
    static boolean enabled=true, music=true;
    private static Theme theme;
    private static int retry;
    static void play(String name){
        if(enabled) MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvent.of(Identifier.of("verityclient",name)),1.0F));
    }
    static void tick(MinecraftClient client,boolean inWorld){
        var manager=client.getSoundManager();
        if(!music || !inWorld){if(theme!=null)manager.stop(theme);theme=null;retry=0;return;}
        if(retry>0){retry--;return;}
        if(theme==null || !manager.isPlaying(theme)){
            if(theme!=null)manager.stop(theme);
            theme=new Theme();manager.play(theme);retry=60;
        }
    }
    private static final class Theme extends MovingSoundInstance {
        Theme(){super(SoundEvent.of(Identifier.of("verityclient","theme")),SoundCategory.MUSIC,Random.create());
            repeat=true;repeatDelay=0;relative=true;attenuationType=SoundInstance.AttenuationType.NONE;volume=.55f;pitch=1f;
        }
        @Override public void tick(){}
    }
}
