package dev.verity.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

final class VerityScreen extends Screen {
    private static final int BG=0xFF151515, PANEL=0xFF242321, LINE=0xFF403923, ACCENT=0xFFFFD72E, TEXT=0xFFF7F2E5, MUTED=0xFFAAA597;
    private static final String[] TABS={"Movement","Combat","Extreme","World","Actions","Verity","Variants"};
    private record Action(String title,String detail,String command) {}
    private static final Action[] ACTIONS={
        new Action("Creative", "Flight and unlimited blocks", "gamemode creative @s"),
        new Action("Survival", "Return to normal gameplay", "gamemode survival @s"),
        new Action("Spectator", "Explore through blocks", "gamemode spectator @s"),
        new Action("Day", "Set time to daytime", "time set day"),
        new Action("Clear Sky", "Stop rain and thunder", "weather clear"),
        new Action("Heal", "Restore health immediately", "effect give @s minecraft:instant_health 1 4 true")
    };
    private record Hit(int x,int y,int w,int h,Runnable click) { boolean contains(double a,double b){return a>=x&&a<x+w&&b>=y&&b<y+h;} }
    private final List<Hit> hits=new ArrayList<>();
    private String tab="Combat";
    private final long opened=System.currentTimeMillis();
    private long closing=0;
    private VerityMascot.Face face=VerityClient.selectedFace;
    VerityScreen(){super(Text.literal("Verity Client"));VerityAudio.play("hello");}
    @Override public void close(){if(closing==0){closing=System.currentTimeMillis();VerityAudio.play("close");}}
    @Override public void tick(){if(closing!=0 && System.currentTimeMillis()-closing>=600 && client!=null)client.setScreen(null);}
    @Override public boolean shouldPause(){return false;}
    private void label(DrawContext c,String s,int x,int y,int color){c.drawTextWithShadow(textRenderer,s,x,y,color);}
    private void tile(DrawContext c,int x,int y,int w,int h,int mx,int my,String name,String detail,String state,boolean enabled,Runnable run){
        boolean hover=mx>=x&&mx<x+w&&my>=y&&my<y+h;
        c.fill(x,y,x+w,y+h,enabled?0xFF4B3D13:hover?0xFF3B3422:PANEL);
        c.fill(x,y,x+2,y+h,enabled?ACCENT:LINE);
        label(c,name,x+8,y+7,TEXT);
        if(h>=30) label(c,textRenderer.trimToWidth(detail,Math.max(1,w-16)),x+8,y+20,MUTED);
        label(c,state,x+w-textRenderer.getWidth(state)-8,y+7,enabled?ACCENT:MUTED);
        hits.add(new Hit(x,y,w,h,run));
    }
    @Override public void render(DrawContext c,int mx,int my,float delta){
        hits.clear();
        long now=System.currentTimeMillis();
        if(closing!=0 || now-opened<1000){
            c.fill(0,0,width,height,0xc0101010);
            int bounce=(int)(Math.sin((now-(closing!=0?closing:opened))/65.0)*5);
            if(closing==0 && now-opened<330){VerityMascot.box(c,width/2-48+bounce,height/2-45,3,false);}else{
                VerityMascot.draw(c,width/2-48,height/2-65+bounce,3,closing!=0?VerityMascot.Face.CHEEKS:VerityMascot.Face.HAPPY);
                if(closing==0)VerityMascot.box(c,width/2-32,height/2+7,2,true);
            }
            String msg=closing!=0?"I WILL BE BACK":"VERITY CLIENT / UNHINGED EDITION";label(c,msg,width/2-textRenderer.getWidth(msg)/2,height/2+45,ACCENT);return;
        }
        c.fill(0,0,width,height,0xA0000000);
        int w=Math.min(560,width-16),h=Math.min(252,height-12),x=(width-w)/2,y=(height-h)/2;
        if(w<210||h<136){label(c,"VERITY / increase GUI resolution",8,8,TEXT);return;}
        c.fill(x,y,x+w,y+h,BG); c.fill(x,y,x+w,y+2,ACCENT);
        label(c,"VERITY CLIENT",x+12,y+12,ACCENT); label(c,"UNHINGED / 5.1",x+94,y+12,MUTED);
        String count=VerityClient.count()+" ACTIVE"; label(c,count,x+w-12-textRenderer.getWidth(count),y+12,TEXT);
        c.fill(x+8,y+28,x+w-8,y+29,LINE);
        int nav=Math.min(102,w/3),tx=x+10,ty=y+36,navStep=Math.min(21,(h-65)/TABS.length);
        for(String t:TABS){boolean selected=t.equals(tab);c.fill(tx,ty,tx+nav-8,ty+navStep-1,selected?PANEL:BG);label(c,t,tx+7,ty+Math.max(0,(navStep-9)/2),selected?ACCENT:MUTED);hits.add(new Hit(tx,ty,nav-8,navStep-1,()->tab=t));ty+=navStep;}
        if(h>=250){int bob=(int)(Math.sin(now/210.0)*2);VerityMascot.draw(c,tx+Math.max(0,(nav-38)/2),ty+4+bob,1,face);}
        int gx=x+nav+8,gw=w-nav-18, gap=5, col=(gw-gap)/2, rowH=Math.min(45,(h-65)/3-3);
        if(tab.equals("Verity")){
            tile(c,gx,y+36,col,rowH,mx,my,"Sound FX","Original meme sounds",VerityAudio.enabled?"ON":"OFF",VerityAudio.enabled,()->{VerityAudio.enabled=!VerityAudio.enabled;VerityAudio.play("on");});
            tile(c,gx+col+gap,y+36,col,rowH,mx,my,"Mascot HUD","Show reactive face",VerityClient.hud?"ON":"OFF",VerityClient.hud,()->VerityClient.hud=!VerityClient.hud);
            tile(c,gx,y+40+rowH,col,rowH,mx,my,"Face swap","Cycle 12 expressions","",true,()->{face=VerityMascot.Face.values()[(face.ordinal()+1)%VerityMascot.Face.values().length];VerityClient.selectedFace=face;VerityAudio.play("hello");});
            tile(c,gx+col+gap,y+40+rowH,col,rowH,mx,my,"Goofy exit","Preview cartoon cheeks","",false,this::close);
            tile(c,gx,y+44+2*rowH,col,rowH,mx,my,"Theme loop","Plays during gameplay",VerityAudio.music?"ON":"OFF",VerityAudio.music,()->{VerityAudio.music=!VerityAudio.music;VerityAudio.tick(client,VerityClient.available(client));});
            tile(c,gx+col+gap,y+44+2*rowH,col,rowH,mx,my,"Elite Ball","Diamond grin","",true,()->{face=VerityMascot.Face.GRILL;VerityClient.selectedFace=face;VerityAudio.play("elite");});
        } else if(tab.equals("Variants")) {
            VerityMascot.Face[] variants={VerityMascot.Face.HAPPY,VerityMascot.Face.STARE,VerityMascot.Face.GLITCH,VerityMascot.Face.SAD,VerityMascot.Face.WAVE,VerityMascot.Face.SLEEP};
            String[] names={"Classic","Suspicious","Glitched","Sad ball","Wave","Sleepy"};
            for(int i=0;i<variants.length;i++){final VerityMascot.Face v=variants[i];tile(c,gx+(i%2)*(col+gap),y+36+(i/2)*(rowH+4),col,rowH,mx,my,names[i],"Select mascot",face==v?"ON":"",face==v,()->{face=v;VerityClient.selectedFace=v;VerityAudio.play(v==VerityMascot.Face.GLITCH?"glitch":"hello");});}
        } else if(tab.equals("Actions")) {
            for(int i=0;i<ACTIONS.length;i++){Action a=ACTIONS[i];tile(c,gx+(i%2)*(col+gap),y+36+(i/2)*(rowH+4),col,rowH,mx,my,a.title,a.detail,"",false,()->VerityClient.action(a.command));}
        } else {
            int i=0; for(VerityClient.Module m:VerityClient.Module.values()) if(m.category.equals(tab)){
                boolean on=VerityClient.enabled(m);tile(c,gx+(i%2)*(col+gap),y+36+(i/2)*(rowH+4),col,rowH,mx,my,m.title,m.description,on?"ON":"OFF",on,()->VerityClient.toggle(m));i++;
            }
        }
        c.fill(x+8,y+h-24,x+w-8,y+h-23,LINE);label(c,"LOCAL ONLY",x+12,y+h-15,ACCENT);
        String rage="RAGE: ALL ON"; int gx2=x+w/2-textRenderer.getWidth(rage)/2; label(c,rage,gx2,y+h-15,ACCENT); hits.add(new Hit(gx2-3,y+h-21,textRenderer.getWidth(rage)+6,19,VerityClient::rage));
        String reset="DISABLE ALL";int rx=x+w-12-textRenderer.getWidth(reset);label(c,reset,rx,y+h-15,MUTED);hits.add(new Hit(rx-3,y+h-21,textRenderer.getWidth(reset)+6,19,VerityClient::reset));
    }
    @Override public boolean mouseClicked(Click click,boolean doubled){if(closing!=0)return true;if(click.button()==0){for(Hit hit:hits)if(hit.contains(click.x(),click.y())){hit.click.run();return true;}}return super.mouseClicked(click,doubled);}
    @Override public boolean keyPressed(KeyInput input){if(input.key()==GLFW.GLFW_KEY_RIGHT_SHIFT){close();return true;}return super.keyPressed(input);}
}
