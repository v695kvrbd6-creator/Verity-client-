package dev.verity.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import java.util.Comparator;
import static dev.verity.client.VerityClient.Module.*;

/** Private-world mob combat sandbox. Never selects a player. */
final class VerityCombat {
    private static final Identifier REACH_ID=Identifier.of("verityclient","reach");
    private static final Identifier BLOCK_ID=Identifier.of("verityclient","block_reach");
    private static final Identifier RAPID_ID=Identifier.of("verityclient","rapid");
    private static int delay;
    private static MobEntity nearest(MinecraftClient c,double range) {
        var p=c.player;
        return c.world.getEntitiesByClass(MobEntity.class,p.getBoundingBox().expand(range),
            m -> m.isAlive() && !m.isRemoved() && p.squaredDistanceTo(m)<=range*range && p.canSee(m))
            .stream().min(Comparator.comparingDouble(m -> p.squaredDistanceTo(m))).orElse(null);
    }
    static void tick(MinecraftClient c) {
        if(!VerityClient.available(c) || c.currentScreen!=null || c.world==null || c.interactionManager==null || !c.player.isAlive() || c.player.isSpectator()) {delay=0;return;}
        boolean aim=VerityClient.enabled(AIMBOT), aura=VerityClient.enabled(AURA), trigger=VerityClient.enabled(TRIGGER);
        if(!aim && !aura && !trigger){delay=0;return;}
        var p=c.player;
        double reach=Math.min(32.0,p.getEntityInteractionRange());
        MobEntity target=(aim||aura)?nearest(c,reach):null;
        if(aim && target!=null){
            Vec3d d=target.getBoundingBox().getCenter().subtract(p.getEyePos());
            p.setYaw((float)Math.toDegrees(Math.atan2(d.z,d.x))-90f);
            p.setPitch((float)-Math.toDegrees(Math.atan2(d.y,Math.hypot(d.x,d.z))));
        }
        if(delay>0){delay--;return;}
        MobEntity victim=aura?target:null;
        if(victim==null && trigger && c.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof MobEntity m && m.isAlive() && p.canSee(m) && p.squaredDistanceTo(m)<=reach*reach) victim=m;
        if(victim!=null && p.getAttackCooldownProgress(0.5f)>=0.95f){
            c.interactionManager.attackEntity(p,victim);
            p.swingHand(Hand.MAIN_HAND);
            delay=VerityClient.enabled(RAPID)?1:3;
        }
    }
    static void attributes(ServerPlayerEntity p,boolean local){
        modifier(p,EntityAttributes.ENTITY_INTERACTION_RANGE,REACH_ID,29,local&&VerityClient.enabled(REACH));
        modifier(p,EntityAttributes.BLOCK_INTERACTION_RANGE,BLOCK_ID,27.5,local&&VerityClient.enabled(BLOCK_REACH));
        modifier(p,EntityAttributes.ATTACK_SPEED,RAPID_ID,36,local&&VerityClient.enabled(RAPID));
    }
    private static void modifier(ServerPlayerEntity p,RegistryEntry<EntityAttribute> type,Identifier id,double amount,boolean on){
        EntityAttributeInstance a=p.getAttributeInstance(type);
        if(a==null)return;
        if(on && !a.hasModifier(id))a.addTemporaryModifier(new EntityAttributeModifier(id,amount,EntityAttributeModifier.Operation.ADD_VALUE));
        else if(!on && a.hasModifier(id))a.removeModifier(id);
    }
}
