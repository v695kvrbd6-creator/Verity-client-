package dev.verity.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.util.Identifier;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.EnumSet;
import java.util.UUID;

public final class VerityClient implements ClientModInitializer {
    enum Module {
        SPEED("Speed", "Movement", "Speed VI", StatusEffects.SPEED, 5),
        HIGH_JUMP("High Jump", "Movement", "Jump Boost V", StatusEffects.JUMP_BOOST, 4),
        SOFT_LANDING("Soft Landing", "Movement", "Slow your descent", StatusEffects.SLOW_FALLING, 0),
        DOLPHIN("Dolphin", "Movement", "Swim faster", StatusEffects.DOLPHINS_GRACE, 0),
        STRENGTH("Strength", "Combat", "Strength VI", StatusEffects.STRENGTH, 5),
        REGEN("Regen", "Combat", "Regeneration IV", StatusEffects.REGENERATION, 3),
        RESISTANCE("Resistance", "Combat", "Resistance IV", StatusEffects.RESISTANCE, 3),
        FIREPROOF("Fireproof", "Combat", "Resist fire damage", StatusEffects.FIRE_RESISTANCE, 0),
        FULLBRIGHT("Fullbright", "World", "See in the dark", StatusEffects.NIGHT_VISION, 0),
        FAST_MINE("Fast Mine", "World", "Haste VI", StatusEffects.HASTE, 5),
        AQUA("Aqua", "World", "Breathe underwater", StatusEffects.WATER_BREATHING, 0),
        AUTO_FEED("Auto Feed", "World", "Maintain hunger", null, 0),
        AIMBOT("Aimbot", "Combat", "Snap to visible mobs", null, 0),
        TRIGGER("Trigger Bot", "Combat", "Attack mobs under crosshair", null, 0),
        REACH("Crazy Reach", "Extreme", "Up to 32 blocks", null, 0),
        AURA("Kill Aura", "Extreme", "Auto-hit nearest visible mob", null, 0),
        RAPID("Rapid Hit", "Extreme", "Boost attack speed", null, 0),
        BLOCK_REACH("Block Reach", "Extreme", "Up to 32 blocks", null, 0),
        CRAZY_SPEED("Crazy Speed", "Extreme", "Speed XX", StatusEffects.SPEED, 19),
        GOD_MODE("God Mode", "Extreme", "Resistance V", StatusEffects.RESISTANCE, 4),
        SUPER_JUMP("Super Jump", "Movement", "Jump Boost XV", StatusEffects.JUMP_BOOST, 14),
        INSTA_MINE("Mega Mine", "World", "Haste XX", StatusEffects.HASTE, 19);
        final String title, category, description;
        final RegistryEntry<StatusEffect> effect;
        final int amplifier;
        Module(String title, String category, String description, RegistryEntry<StatusEffect> effect, int amplifier) {
            this.title=title; this.category=category; this.description=description; this.effect=effect; this.amplifier=amplifier;
        }
    }
    private static final EnumSet<Module> active = EnumSet.noneOf(Module.class);
    private static IntegratedServer world;
    private static UUID owner;
    private static int ticks;
    private static KeyBinding menu;
    static String notice="";
    static long noticeUntil;
    static boolean hud=true;
    static VerityMascot.Face selectedFace=VerityMascot.Face.HAPPY;
    static void notifyUser(String message){notice=message;noticeUntil=System.currentTimeMillis()+2300;}
    static boolean available(MinecraftClient client) {
        IntegratedServer server = client.getServer();
        return client.player != null && client.isInSingleplayer() && server != null && !server.isRemote();
    }
    static synchronized boolean enabled(Module m) { return active.contains(m); }
    static synchronized int count() { return active.size(); }
    static synchronized void toggle(Module m) {
        if (!available(MinecraftClient.getInstance())) return;
        boolean on=!active.remove(m); if(on) active.add(m);
        notifyUser("Verity: "+m.title+(on?" is yours!":" off")); VerityAudio.play(on?"on":"off");
    }
    static synchronized void rage() { if (!available(MinecraftClient.getInstance())) return; active.addAll(EnumSet.allOf(Module.class)); selectedFace=VerityMascot.Face.GRILL; notifyUser("BLATANT MODE: ALL MODULES ON"); VerityAudio.play("elite"); }
    static synchronized void reset() { active.clear(); notifyUser("Everything off"); VerityAudio.play("off"); }
    @Override public void onInitializeClient() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of("verityclient","hud"), (ctx,tickCounter)->{
            MinecraftClient c=MinecraftClient.getInstance();
            if(!hud || !available(c) || c.currentScreen!=null) return;
            int x=8,y=8, sw=c.getWindow().getScaledWidth(), sh=c.getWindow().getScaledHeight();
            int yellow=0xffffd72e;
            ctx.fill(x,y,x+172,y+39,0xe2141516);ctx.fill(x,y,x+172,y+2,yellow);
            VerityMascot.draw(ctx,x+3,y+4,1,c.player.getHealth()<=6?VerityMascot.Face.SHOCKED:count()>0?VerityMascot.Face.SMUG:selectedFace);
            ctx.drawTextWithShadow(c.textRenderer,"VERITY CLIENT / 5.1",x+39,y+8,yellow);
            ctx.drawTextWithShadow(c.textRenderer,"UNHINGED  |  "+count()+" ACTIVE",x+39,y+23,0xffeeeeee);
            int yy=8;
            java.util.List<Module> shown=new java.util.ArrayList<>();
            for(Module m:Module.values()) if(enabled(m)) shown.add(m);
            shown.sort(java.util.Comparator.comparingInt((Module m)->c.textRenderer.getWidth(m.title)).reversed());
            for(Module m:shown){int ww=c.textRenderer.getWidth(m.title)+12;ctx.fill(sw-ww-8,yy,sw-8,yy+12,0xd5151515);ctx.fill(sw-9,yy,sw-7,yy+12,yellow);ctx.drawTextWithShadow(c.textRenderer,m.title,sw-ww-3,yy+2,yellow);yy+=13;}
            if(sh>130){int bx=8,by=sh-68;VerityMascot.draw(ctx,bx,by,2,selectedFace);}
            if(System.currentTimeMillis()<noticeUntil){int ww=Math.max(110,c.textRenderer.getWidth(notice)+43);int nx=Math.max(0,(sw-ww)/2);ctx.fill(nx,48,nx+ww,84,0xe51c1c1d);VerityMascot.draw(ctx,nx+2,50,1,VerityMascot.Face.PEACE);ctx.drawTextWithShadow(c.textRenderer,notice,nx+36,62,yellow);}
        });
        menu=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.verityclient.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.create(Identifier.of("verityclient","main"))));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            VerityAudio.tick(client,available(client));
            synchronized (VerityClient.class) {
                if (!available(client)) { active.clear(); world=null; owner=null; noticeUntil=0; }
                else if (world != client.getServer()) {
                    active.clear(); world=client.getServer(); owner=client.player.getUuid(); ticks=0;
                }
            }
            VerityCombat.tick(client);
            while(menu.wasPressed()) {
                if (available(client) && client.currentScreen == null) client.setScreen(new VerityScreen());
                else if (client.currentScreen instanceof VerityScreen screen) screen.close();
                else if (client.player != null && !available(client)) client.player.sendMessage(Text.literal("Verity: private single-player only."), true);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            synchronized (VerityClient.class) {
                // Always remove temporary attribute bonuses if the world is opened to LAN.
                boolean allowed=server == world && owner != null && !server.isRemote();
                for(ServerPlayerEntity player:server.getPlayerManager().getPlayerList()) {
                    boolean local=allowed && player.getUuid().equals(owner);
                    VerityCombat.attributes(player,local);
                }
                if (!allowed || ++ticks % 10 != 0) return;
                ServerPlayerEntity p=server.getPlayerManager().getPlayer(owner);
                if (p == null || !p.isAlive()) return;
                for (Module m: active) {
                    if (m == Module.AUTO_FEED) { p.getHungerManager().add(20, 1.0F); continue; }
                    if(m.effect==null) continue;
                    if((m==Module.SPEED && active.contains(Module.CRAZY_SPEED)) ||
                       (m==Module.HIGH_JUMP && active.contains(Module.SUPER_JUMP)) ||
                       (m==Module.RESISTANCE && active.contains(Module.GOD_MODE)) ||
                       (m==Module.FAST_MINE && active.contains(Module.INSTA_MINE))) continue;
                    StatusEffectInstance current=p.getStatusEffect(m.effect);
                    // Avoid replacing a stronger or long-lived existing potion effect.
                    if (current == null || (current.getAmplifier() <= m.amplifier && current.getDuration() >= 0 && current.getDuration() <= 30)) {
                        p.addStatusEffect(new StatusEffectInstance(m.effect, 40, m.amplifier, true, false, false));
                    }
                }
            }
        });
    }
    static void action(String command) {
        MinecraftClient c=MinecraftClient.getInstance();
        if (!available(c)) return;
        IntegratedServer s=c.getServer(); UUID id=c.player.getUuid();
        notifyUser("World action applied"); VerityAudio.play("on");
        s.execute(() -> {
            if (s.isRemote()) return;
            ServerPlayerEntity p=s.getPlayerManager().getPlayer(id);
            if (p != null) s.getCommandManager().parseAndExecute(p.getCommandSource().withPermissions(s.getCommandSource().getPermissions()), command);
        });
    }
}
