package dev.verity.client;
import net.minecraft.client.gui.DrawContext;
/** Original sphere artwork inspired by the floating smiley assistant. */
final class VerityMascot {
    enum Face { HAPPY, SMUG, SHOCKED, MAD, PEACE, CHEEKS, SAD, STARE, GRILL, WAVE, GLITCH, SLEEP }
    static final int INK=0xff211803;
    private static void r(DrawContext c,int x,int y,int s,int a,int b,int w,int h,int col){c.fill(x+a*s,y+b*s,x+(a+w)*s,y+(b+h)*s,col);}
    private static void ellipse(DrawContext c,int x,int y,int s,int a,int b,int w,int h,int col){
        for(int k=0;k<h;k++){double v=(k+.5-h/2.0)/(h/2.0);int n=(int)Math.round(w/2.0*Math.sqrt(Math.max(0,1-v*v)));if(n>0)r(c,x,y,s,a+w/2-n,b+k,n*2,1,col);}
    }
    static void box(DrawContext c,int x,int y,int s,boolean open){
        r(c,x,y,s,2,12,28,19,0xff896036);r(c,x,y,s,3,13,18,17,0xffbd925a);r(c,x,y,s,21,13,8,17,0xff997042);r(c,x,y,s,10,13,5,17,0xffe3c28a);
        if(open){r(c,x,y,s,0,9,13,4,0xffd9af74);r(c,x,y,s,19,9,13,4,0xffae7d48);r(c,x,y,s,13,11,6,3,0xff49331c);}else{r(c,x,y,s,2,9,28,5,0xffd4aa71);r(c,x,y,s,10,9,5,5,0xffe3c28a);}
    }
    static void draw(DrawContext c,int x,int y,int s,Face f){
        String name=f.name().toLowerCase(java.util.Locale.ROOT);
        if(f==Face.HAPPY && System.currentTimeMillis()%4600<125)name="blink";
        int size=32*s;
        c.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED,
            net.minecraft.util.Identifier.of("verityclient","textures/gui/"+name+".png"),x,y,0f,0f,size,size,256,256,256,256);
    }
}
